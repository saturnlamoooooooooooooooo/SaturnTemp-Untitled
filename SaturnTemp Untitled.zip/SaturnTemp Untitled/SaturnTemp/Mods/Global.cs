﻿using static SaturnTemp.Menu.Main;

namespace SaturnTemp.Mods
{
    internal class Global
    {
        public static void ReturnHome()
        {
            buttonsType = 0;
        }
    }
}
