﻿namespace SaturnTemp
{
    internal class PluginInfo
    {
        public const string GUID = "org.saturn.gorillatag.untitled";
        public const string Name = "Saturn Temp";
        public const string Description = "Created by saturn with love <3";
        public const string Version = "1.0.0";
    }
}
